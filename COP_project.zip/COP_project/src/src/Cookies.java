package src;

public class Cookies {
    private static Cookies instance; // Singleton instance
    private String token;

    // Private constructor to prevent instantiation from other classes
    private Cookies() {}

    // Static method to get the instance of the class
    public static synchronized Cookies getInstance() {
        if (instance == null) {
            instance = new Cookies();
        }
        return instance;
    }

    public boolean isLoggedIn() {
        return token != null && !token.isEmpty();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}