package src; /** Starts game application by putting it into JFrame. **/

import javax.swing.*;

public class StartApplet {

    public static void main(String[] args) {

        // Create custom login dialog + display to get user credentials
        LoginDialogManager.getInstance().showLoginDialog();

        // Click OK or press Enter to go to main app
    }
}
