package src; /** Log in or register new user to enter Applet. **/

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean succeeded;
    private Map<String, String> userDatabase;
    private static final String USER_DATABASE_FILE = "userDatabase.txt";

    public LoginDialog(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        this.succeeded = false;
        //this.userDatabase = new HashMap<>();
        //loadUserDatabase();

        // This doesn't work for my desktop for some reason, it looked pretty once and I dunno how to do it again
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.CYAN);

        JPanel loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("Username: ");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(10, 10, 0, 10);
        loginPanel.add(usernameLabel, constraints);

        usernameField = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        loginPanel.add(usernameField, constraints);

        JLabel passwordLabel = new JLabel("Password: ");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        loginPanel.add(passwordLabel, constraints);

        passwordField = new JPasswordField(20);
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        loginPanel.add(passwordField, constraints);
        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        JButton loginButton = new JButton("Login!");
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        loginPanel.add(loginButton, constraints);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        JButton registerButton = new JButton("Register!");
		
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        loginPanel.add(registerButton, constraints);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });

        contentPane.add(loginPanel, BorderLayout.CENTER);

        setContentPane(contentPane);
        pack();
        setLocationRelativeTo(parent);
    }

    /** Looking at user database file for checking usernames and putting new registration info in. **/
    private void loadUserDatabase() {
        File file = new File(USER_DATABASE_FILE);
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(":");
                    if (parts.length == 2) {
                        userDatabase.put(parts[0], parts[1]);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /** Put new user info. **/
    private void saveUserDatabase() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(USER_DATABASE_FILE))) {
            for (Map.Entry<String, String> entry : userDatabase.entrySet()) {
                writer.println(entry.getKey() + ":" + entry.getValue());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Actually try to log in. **/
    private void login() {
        // Check if credentials match admin username and password because I want to be lazy
		/*
        if ("admin".equals(username) && "admin".equals(password)) {
            succeeded = true;
            dispose();
            return;
        }

        // Check if username exists in the database
        if (userDatabase.containsKey(username)) {
            // Check if password matches stored password
            if (userDatabase.get(username).equals(password)) {
                succeeded = true;
                JOptionPane.showMessageDialog(this,
                        "Flap on in!",
                        "Login Successful!",
                        JOptionPane.INFORMATION_MESSAGE);
                dispose();
                return;
            }
        }*/
		
		try {
            URL url = new URL("https://wtmapp.us/classapi/signin");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String jsonInputString = String.format("{\"username\": \"%s\", \"password\": \"%s\"}", username, password);
            
            try(OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                StringBuilder response = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                System.out.println(response);
                String cookiesHeader = connection.getHeaderField("Set-Cookie");
                if (cookiesHeader != null) {
                    String[] cookies = cookiesHeader.split(";\\s*");
                    String token = null;
                    for (String cookie : cookies) {
                        if (cookie.startsWith("authToken=")) {
                            token = cookie.substring("authToken=".length());
                            break;
                        }
                    }
                    if (token != null) {
                        // Use the token as needed, for example, store it
                        Cookies.getInstance().setToken(token);
                        System.out.println("Token: " + token);
                        JOptionPane.showMessageDialog(this, "Login Successful!");
        				
        				this.dispose();
        				JFrame jFrame = new JFrame();

        				 // Initializing Applet
        				 SwoopGameplay swoopApplet = new SwoopGameplay();
        				 swoopApplet.init();
        				 jFrame.setResizable(false);
        				 jFrame.setSize(swoopApplet.APP_WIDTH, swoopApplet.APP_HEIGHT);
        				 jFrame.setLocationRelativeTo(null);
        				 jFrame.setVisible(true);
        				 jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        				 jFrame.add(swoopApplet);
        				 swoopApplet.start();
        				 SoundEffects.playSound("src/Sounds/pixelsong.wav", true);
        				 jFrame.setTitle("SWOOP d'LOOP! - Team 2");

                    } else {
                    	
                        System.out.println("Token not found in cookies.");
                        usernameField.setText("");
        				passwordField.setText("");
                        JOptionPane.showMessageDialog(this, "Login Failed!");
                    }
                } else {
                    System.out.println("No cookies in response.");
                    usernameField.setText("");
    				passwordField.setText("");
                    JOptionPane.showMessageDialog(this, "Login Failed!");
                }				//do whatever here to continue to the game 
				
				
            } else {
				usernameField.setText("");
				passwordField.setText("");
                JOptionPane.showMessageDialog(this, "Login Failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
			succeeded = false;
        }
    }


        // If authentication fails, show error
		/*
        JOptionPane.showMessageDialog(this,
                "sWoops... we don't have that on file.",
                "Login Failed! :(",
                JOptionPane.ERROR_MESSAGE);
        usernameField.setText("");
        passwordField.setText("");
        succeeded = false;*/

    /** Register as a new user. **/
    private void register() {
    	SignupForm SignupForm = new SignupForm(null, "Swoop! Please SignUp!", true);
    	SignupForm.setVisible(true);// Assuming the SignUpForm is defined similarly to previous example
    	// Close the login form
		/*
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Check if the username is already registered/used
        if (userDatabase.containsKey(username)) {
            JOptionPane.showMessageDialog(this,
                    "sWoops... Username already exists. Please choose a different username.",
                    "Registration Failed! :(",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Register new user
        userDatabase.put(username, password);
        saveUserDatabase(); // Save user database to file
        JOptionPane.showMessageDialog(this,
                "User '" + username + "' registered successfully! Flap on in!",
                "SWOOP! :) Registration Successful!",
                JOptionPane.INFORMATION_MESSAGE);*/
    }

    /** To start the rest of the Applet. **/
    public boolean isSucceeded() {

        return succeeded;
    }
}
