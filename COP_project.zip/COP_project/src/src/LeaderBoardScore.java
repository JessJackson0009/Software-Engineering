package src;

public class LeaderBoardScore {
    private String username;
    private int scoreValue;

    public LeaderBoardScore(String username, int scoreValue) {
        this.username = username;
        this.scoreValue = scoreValue;
    }

    public String getUsername() {
        return username;
    }

    public int getScoreValue() {
        return scoreValue;
    }
}