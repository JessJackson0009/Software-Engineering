/** Big gameplay loop. Pretty much the whole game is here. **/
package src;

import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
//import javax.swing.*;
import java.io.InputStreamReader;



import javax.swing.JOptionPane;

import org.json.JSONArray;
import org.json.JSONObject;

public class SwoopGameplay extends GraphicsProgram {

final static int APP_WIDTH = 576,
		APP_HEIGHT = 768,
		GROUND_LEVEL = 620,
		PIPE_WIDTH = 52,
		OSPREY_X_COORD = 255;

	Osprey osprey;
	BotSprey botSprey;

	ScoreOutputs scoreOutputs;

	static int gameplayMode = 0;
	// 0 = Instructions, 1 = Game, 2 = Falling, 3 = Game Over
	static int score = 0;
	private volatile boolean running = true;
	// Boolean to control game loop
	private volatile boolean paused = false;
	// Boolean to track whether game is paused or not

	@Override public void init() {

		setSize(APP_WIDTH, APP_HEIGHT);
		Sprites.init();
		initializeNums(true);

		// Instantiate Osprey, bot too
		osprey = new Osprey(SwoopGameplay.OSPREY_X_COORD, APP_WIDTH /2);
		botSprey = new BotSprey(SwoopGameplay.OSPREY_X_COORD -20, APP_WIDTH /2);

		// new fileHandler to deal with saving to a file
		scoreOutputs = new ScoreOutputs();

		// Adding images to screen
		resetPipes();
		add(Sprites.background);
		for(int i = 0; i < 4; i++){ add(Sprites.pipeTop[i]); add(Sprites.pipeBottom[i]); }
		add(Sprites.foreground);
		add(Sprites.swoopLogo);
		add(Sprites.tapInstructions);
		add(Sprites.botspreyFlapUp);
		add(Sprites.ospreyFlapUp);
		add(Sprites.pauseIcon);
		add(Sprites.menuBoard);
		add(Sprites.logIn);
		add(Sprites.newUser);
		add(Sprites.preGame1);

		// This is for the scoreboard
		for(int i = 0; i < 10; i ++){
			Sprites.scoreNums[i] = new GImage(Sprites.currentScoreNums[0].getImage());
			Sprites.scoreNums[i].setLocation(-100, 0);
			add(Sprites.scoreNums[i]);
		}
		drawGameScore();

		addMouseListeners();
		addKeyListeners();

	}

	/** Gameplay Loop **/
	@Override public void run(){

		int groundOffset = 0;

		while(running) {
			if (!paused) {
				// 0 = Instructions, 1 = Game, 2 = Falling, 3 = Game Over
				if (SwoopGameplay.gameplayMode == 1 || SwoopGameplay.gameplayMode == 2) {

					osprey.fly();
					botSprey.botFly();

					// Did Osprey/Bot hit ground
					if (osprey.getY() + osprey.hoverCounter > SwoopGameplay.GROUND_LEVEL - Sprites.ospreyOG.getHeight()) {
						SoundEffects.playSound("src/Sounds/falling1.wav", false);
						osprey.fallingSpeed = 0;
						endSwoop();
					}
					if (botSprey.getY() + botSprey.hoverCounter > SwoopGameplay.GROUND_LEVEL - Sprites.botspreyOG.getHeight()) {
						remove(Sprites.botspreyFlapUp);
						remove(Sprites.botspreyFlapDown);
						remove(Sprites.botspreyOG);
					}
				}

				// Playing the game
				if (SwoopGameplay.gameplayMode == 1) {
					movePipes();

					// Osprey/Bot pipe collision
					if (osprey.pipeCollision()) {
						SoundEffects.playSound("src/Sounds/smack.wav", false);
						osprey.fallingSpeed = Math.min(0, osprey.fallingSpeed);
						gameplayMode = 2;
					}
					if (botSprey.botPipeCollision()) {
						botSprey.fallingSpeed = Math.min(0, botSprey.fallingSpeed);
					}

				}

				// Foreground
				if (SwoopGameplay.gameplayMode < 2) {
					Sprites.foreground.setLocation(-groundOffset, SwoopGameplay.GROUND_LEVEL);
					groundOffset = (groundOffset + 5) % 40;

				}

				// Draw Bot/Osprey
				if (SwoopGameplay.gameplayMode < 3) {
					botSprey.botDraw(this);
				}
				if (SwoopGameplay.gameplayMode < 3)
					osprey.draw(this);
				pause(20);
			}
		}
	}

	/** For pressing space, up or w **/
	@Override
	public void keyPressed(KeyEvent key) {
		int keyCode = key.getKeyCode();
		char character = key.getKeyChar();

		if (keyCode == KeyEvent.VK_SPACE || keyCode == KeyEvent.VK_UP || character == 'w') {
			respondInput();
		}
	}

	/** For pressing everywhere with a mouse **/
	@Override public void mousePressed(MouseEvent mouse) {
		if (SwoopGameplay.gameplayMode == 3) {
			if (mouse.getX() >= Sprites.replayButton.getX() && mouse.getX() <= Sprites.replayButton.getX() + Sprites.replayButton.getWidth() &&
					mouse.getY() >= Sprites.replayButton.getY() && mouse.getY() <= Sprites.replayButton.getY() + Sprites.replayButton.getHeight()) {
				// Clicked on  replay button
				remove(Sprites.menuBoard);
				replaySwoop();
				return;
			}

			if (mouse.getX() >= Sprites.scoreIcon.getX() && mouse.getX() <= Sprites.scoreIcon.getX() + Sprites.scoreIcon.getWidth() &&
					mouse.getY() >= Sprites.scoreIcon.getY() && mouse.getY() <= Sprites.scoreIcon.getY() + Sprites.scoreIcon.getHeight()) {
				// Clicked on score icon
				add(Sprites.menuBoard);
				Sprites.menuBoard.setLocation(170, 195);
//				List<Integer> topScores = scoreOutputs.getTopScores();
//				drawScores(topScores);
				displayLeaderBoard();
			}

			if (mouse.getX() >= Sprites.postGame.getX() && mouse.getX() <= Sprites.postGame.getX() + Sprites.postGame.getWidth() &&
					mouse.getY() >= Sprites.postGame.getY() && mouse.getY() <= Sprites.postGame.getY() + Sprites.postGame.getHeight()) {
				openPostgameGooglePoll();
				return;
			}
		}

		if(SwoopGameplay.gameplayMode == 0){
			// Check if mouse click is within preGame poll icon while Instructions
			if (mouse.getX() >= Sprites.preGame1.getX() && mouse.getX() <= Sprites.preGame1.getX() + Sprites.preGame1.getWidth() &&
					mouse.getY() >= Sprites.preGame1.getY() && mouse.getY() <= Sprites.preGame1.getY() + Sprites.preGame1.getHeight())
				openPregameGooglePoll();
		}

		if (mouse.getX() >= Sprites.pauseIcon.getX() && mouse.getX() <= Sprites.pauseIcon.getX() + Sprites.pauseIcon.getWidth() &&
				mouse.getY() >= Sprites.pauseIcon.getY() && mouse.getY() <= Sprites.pauseIcon.getY() + Sprites.pauseIcon.getHeight()) {
			pauseSwoop();
		}

		if (paused) {
			// Check if mouse click is within preGame poll icon while paused
			if (mouse.getX() >= Sprites.preGame.getX() && mouse.getX() <= Sprites.preGame.getX() + Sprites.preGame.getWidth() &&
					mouse.getY() >= Sprites.preGame.getY() && mouse.getY() <= Sprites.preGame.getY() + Sprites.preGame.getHeight()) {
				openPregameGooglePoll();
			}
			// If mouse click is within scoreboard icon
			if (mouse.getX() >= Sprites.scoreIcon.getX() && mouse.getX() <= Sprites.scoreIcon.getX() + Sprites.scoreIcon.getWidth() &&
					mouse.getY() >= Sprites.scoreIcon.getY() && mouse.getY() <= Sprites.scoreIcon.getY() + Sprites.scoreIcon.getHeight()) {
				// Show current scoreboard menu and draw scores
				add(Sprites.menuBoard);
				Sprites.menuBoard.setLocation(170, 195);
//				List<Integer> topScores = scoreOutputs.getTopScores();
//				drawScores(topScores);
				displayLeaderBoard();
			}
		}
		respondInput();
	}

	private void openPregameGooglePoll() {
		try {
			Desktop.getDesktop().browse(new URI("https://forms.gle/aNjct7GUQqaBbohj8"));
		} catch (IOException | URISyntaxException e) {
			System.err.println("Error opening pregame Google poll: " + e.getMessage());
		}
	}

	private void openPostgameGooglePoll() {
		try {
			Desktop.getDesktop().browse(new URI("https://forms.gle/4f6BQmh28k8TWLuP7"));
		} catch (IOException | URISyntaxException e) {
			System.err.println("Error opening postgame Google poll: " + e.getMessage());
		}
	}

	// Pause game
	private void pauseSwoop() {
		paused = !paused;

		if (paused) {
			// Show play icon, hide pause icon when paused
			add(Sprites.playIcon);
			remove(Sprites.pauseIcon);
			add(Sprites.scoreboard);
			add(Sprites.scoreIcon);
			add(Sprites.preGame);

			// Get high score from file
			String strHighScore = scoreOutputs.getHighScore();
			int highScore = Integer.parseInt(strHighScore);

			// Update HighScore
			if (score > highScore){
				scoreOutputs.updateHighScore(Integer.toString(score));
				drawMenuScore(1, score );
			}
			else{
				drawMenuScore(1, highScore);
			}

			drawMenuScore(0, score);

		} else {
			// Show pause icon, hide play icon when not paused
			add(Sprites.background);
			add(Sprites.pauseIcon);
			for(int i = 0; i < 4; i++){ add(Sprites.pipeTop[i]); add(Sprites.pipeBottom[i]); }
			add(Sprites.foreground);

			drawGameScore();

			remove(Sprites.playIcon);
			remove(Sprites.scoreboard);
			remove(Sprites.scoreIcon);
			remove(Sprites.preGame);
			initializeNums(false);
		}

	}

	/** Flaps or changes game state. **/
	public void respondInput(){
		if(SwoopGameplay.gameplayMode == 0){
			SwoopGameplay.gameplayMode = 1;
			remove(Sprites.swoopLogo);
			remove(Sprites.tapInstructions);
			remove(Sprites.logIn);
			remove(Sprites.newUser);
			remove(Sprites.preGame1);
		}
		else if(SwoopGameplay.gameplayMode == 1){
			osprey.capHeight();
			SoundEffects.playSound("src/Sounds/flapping.wav", false);
		}

	}

	public void movePipes(){
		for(int i = 0; i < 4; i++){
			Sprites.pipeBottom[i].move(-4, 0);
			Sprites.pipeTop[i].move(-4, 0);

			// Check if Osprey passed pipes (score)
			if(Sprites.pipeBottom[i].getX() == (APP_WIDTH /2) + 2){
				score++;
				drawGameScore();
				SoundEffects.playSound("src/Sounds/coin.wav", false);
			}

			// Respawn pipes
			if(Sprites.pipeBottom[i].getX() < -(APP_WIDTH /4) - (PIPE_WIDTH/2)){
				Sprites.pipeTop[i].setLocation(APP_WIDTH + (APP_WIDTH /4) - (PIPE_WIDTH/2), -80);
				Sprites.pipeBottom[i].setLocation(APP_WIDTH + (APP_WIDTH /4) - (PIPE_WIDTH/2), (GROUND_LEVEL/2));
				randomPipesHeights(i);
			}

		}

	}

	public void resetPipes(){
		for(int i = 0; i < 4; i++){
			Sprites.pipeTop[i].setLocation(APP_WIDTH *2 + i*(APP_WIDTH /3) - (PIPE_WIDTH/2), -80);
			Sprites.pipeBottom[i].setLocation(APP_WIDTH *2 + i*(APP_WIDTH /3) - (PIPE_WIDTH/2), (GROUND_LEVEL/2));
			randomPipesHeights(i);
		}
	}

	/** Randomizes pipe heights. **/
	public void randomPipesHeights(int i){
		int randomAltitude = (int) (Math.random() * (GROUND_LEVEL/2) ) - 101;
		Sprites.pipeTop[i].move(0, randomAltitude - 50);
		Sprites.pipeBottom[i].move(0, randomAltitude + 50);
	}


	/** Changing up the graphics for a gameOver. **/
	public void endSwoop(){

		SwoopGameplay.gameplayMode = 3;

		remove(Sprites.ospreyFlapUp);
		remove(Sprites.ospreyFlapDown);
		remove(Sprites.ospreyOG);
		add(Sprites.ospreyGameOver);
		add(Sprites.foreground);
		add(Sprites.gameOver);
		add(Sprites.scoreboard);
		add(Sprites.replayButton);
		remove(Sprites.pauseIcon);
		add(Sprites.scoreIcon);
		add(Sprites.postGame);

		// Get highscore from file and update
		String strHighScore = scoreOutputs.getHighScore();
		int highScore = Integer.parseInt(strHighScore);
		if (score > highScore){
			scoreOutputs.updateHighScore(Integer.toString(score));
			drawMenuScore(1, score );
			Sprites.newScoreTag.setLocation(175, 276);
		}
		else{
			drawMenuScore(1, highScore);
			Sprites.newScoreTag.setLocation(-100, 0);
		}

		// Append new high score to the file
		scoreOutputs.appendHighScore(Integer.toString(score));
		add(Sprites.newScoreTag);
		drawMenuScore(0, score);
		checkAndSubmitScore();
	}

	/** Reset graphics **/
	public void replaySwoop(){

		add(Sprites.background);
		for(int i = 0; i < 4; i++){ add(Sprites.pipeTop[i]); add(Sprites.pipeBottom[i]); }
		add(Sprites.foreground);

		remove(Sprites.replayButton);
		remove(Sprites.gameOver);
		remove(Sprites.ospreyGameOver);
		remove(Sprites.scoreIcon);
		remove(Sprites.postGame);

		botSprey.setY(APP_WIDTH /2);
		osprey.setY(APP_WIDTH /2);
		botSprey.fallingSpeed = 0;
		botSprey.hoverCounter = 0;
		osprey.fallingSpeed = 0;
		osprey.hoverCounter = 0;

		SwoopGameplay.gameplayMode = 0;

		resetPipes();
		add(Sprites.swoopLogo);
		add(Sprites.tapInstructions);
		add(Sprites.pauseIcon);
		remove(Sprites.scoreboard);
		remove(Sprites.newScoreTag);

		// Reset score
		score = 0;
		initializeNums(false);
		drawGameScore();

	}

	/** Initializes images for the running total digits **/
	public void initializeNums(boolean initialCall){

		for(int i = 0; i < 20; i ++){

			if(!initialCall)
				remove(Sprites.boardNums[i]);

			Sprites.boardNums[i] = new GImage(Sprites.highScoreNums[0].getImage());
			Sprites.boardNums[i].setLocation(-100, 0);
			add(Sprites.boardNums[i]);

		}

	}

	/** Draws number on score board (final = 0 or previous high score = 1) **/
	protected void drawMenuScore(int mode, int points) {
		final int START_X = 210;
		final int SCOREBOARD_Y = 229;
		final int DIGIT_SPACING = 1;
		final int DIGIT_HEIGHT = 42;

		boolean drawRemainingDigits = true;
		int currentX = START_X;

		int remainingPoints = points; // Initialize remainingPoints with points

		// Calculate the number of digits in points
		int numDigits = (points == 0) ? 1 : (int) Math.log10(points) + 1;
		currentX -= (numDigits - 1) * DIGIT_SPACING;

		// Reverse order of digits in points
		int reversedPoints = 0;
		while (remainingPoints != 0) {
			int digitValue = remainingPoints % 10;
			reversedPoints = reversedPoints * 10 + digitValue;
			remainingPoints /= 10;
		}

		for (int digitIndex = 0; digitIndex < numDigits; digitIndex++) {
			remove(Sprites.boardNums[digitIndex + mode * 10]);

			// Extract last digit
			int digitValue = reversedPoints % 10;
			reversedPoints /= 10;
			Sprites.boardNums[digitIndex + mode * 10] = new GImage(Sprites.highScoreNums[digitValue].getImage());

			if (drawRemainingDigits || digitIndex == 0) {
				Sprites.boardNums[digitIndex + mode * 10].setLocation(currentX, SCOREBOARD_Y + mode * DIGIT_HEIGHT);
			} else {
				Sprites.boardNums[digitIndex + mode * 10].setLocation(-100, 0);
			}

			add(Sprites.boardNums[digitIndex + mode * 10]);

			// Update currentX for the next digit
			currentX += Sprites.boardNums[digitIndex + mode * 10].getWidth() + DIGIT_SPACING;
			
			
		}
	}



	/** Draws current score. **/
	protected void drawGameScore() {
		final int SCORE_Y = 50;
		final int DIGIT_GAP = 1;
		final int DIGIT_START_X = (APP_WIDTH / 2);

		List<GImage> scoreDigitsList = new ArrayList<>();

		int scoreCopy = score;
		int widthScore = 0;

		do {
			int digitValue = scoreCopy % 10;
			GImage digitImage = new GImage(Sprites.currentScoreNums[digitValue].getImage());
			widthScore += digitImage.getWidth() + DIGIT_GAP;
			scoreDigitsList.add(digitImage);
			scoreCopy /= 10;
		} while (scoreCopy > 0);

		int startX = DIGIT_START_X - (widthScore / 2);

		// Remove previous score digits
		for (GImage digit : Sprites.scoreNums) {
			if (digit != null) {
				remove(digit);
			}
		}

		// Draw score digits on screen
		for (int i = scoreDigitsList.size() - 1; i >= 0; i--) {
			GImage digitImage = scoreDigitsList.get(i);
			digitImage.setLocation(startX, SCORE_Y);
			add(digitImage);
			startX += digitImage.getWidth() + DIGIT_GAP;
		}

		// Update Sprites.scoreDigits array with new digits
		Sprites.scoreNums = scoreDigitsList.toArray(new GImage[0]);
	}

	
	private List<LeaderBoardScore> fetchLeaderBoard() {
		List<LeaderBoardScore> scores = new ArrayList<>();
		try {
			URL url = new URL("https://wtmapp.us/classapi/leaderboard");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			StringBuilder response = new StringBuilder();
			while ((line = reader.readLine()) != null) {
				response.append(line);
			}
			reader.close();

			// Assuming the use of a JSON parsing library to parse `response.toString()`
			// Parse the JSON response and populate the `scores` list
			JSONArray jsonArray = new JSONArray(response.toString());
			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				String username = jsonObject.getString("username");
				int score = jsonObject.getInt("score");
				scores.add(new LeaderBoardScore(username, score));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return scores;
	}


	
    public void checkAndSubmitScore() {
        if (!Cookies.getInstance().isLoggedIn()) {
            // Prompt user to log in or sign up
			List<LeaderBoardScore> scores = fetchLeaderBoard();
			boolean higherScore = scores.stream().anyMatch(s -> score > s.getScoreValue());
			Boolean numscores = scores.size()<10;
			if (higherScore ||numscores) {
				int response = JOptionPane.showConfirmDialog(null, "Would you like to log in or sign up to submit your score?", "Not Logged In", JOptionPane.YES_NO_OPTION);
				if (response == JOptionPane.YES_OPTION) {
					LoginDialogManager.getInstance().showLoginDialog(); // You'll need to adjust LoginForm to support callback or similar after successful login

				} else {
					add(Sprites.menuBoard);
					Sprites.menuBoard.setLocation(170, 195);
					displayLeaderBoard();
				}
			} else {
				add(Sprites.menuBoard);
				Sprites.menuBoard.setLocation(170, 195);
					displayLeaderBoard();
			}	
        } else {
			List<LeaderBoardScore> scores = fetchLeaderBoard();
			boolean higherScore = scores.stream().anyMatch(s -> score > s.getScoreValue());
			Boolean numscores = scores.size()<10;
			if (higherScore ||numscores) {
				int response = JOptionPane.showConfirmDialog(null, "Your score is higher! Would you like to submit it?", "Submit Score", JOptionPane.YES_NO_OPTION);
				if (response == JOptionPane.YES_OPTION) {
					submitScore();
				} else {
					add(Sprites.menuBoard);
					Sprites.menuBoard.setLocation(170, 195);
					displayLeaderBoard();
				}
			} else {
				add(Sprites.menuBoard);
				Sprites.menuBoard.setLocation(170, 195);
				displayLeaderBoard();
			}
		}
    }

	private void submitScore() {
		try {
			URL url = new URL("https://wtmapp.us/classapi/submit-score");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setDoOutput(true);
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setRequestProperty("Cookie", "authToken=" + Cookies.getInstance().getToken());
			
			// Prepare JSON body with the score
			String jsonInputString = String.format("{\"score\":%d}", score);
			
			try (OutputStream os = connection.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}
			
			int responseCode = connection.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
				// Assuming the submission was successful
				JOptionPane.showMessageDialog(null, "Score submitted successfully!");
			} else {
				// Handle unsuccessful submission
				JOptionPane.showMessageDialog(null, "Failed to submit score.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error submitting score: " + e.getMessage());
		}
		// Fetch and display the updated leaderboard after submission
		add(Sprites.menuBoard);
		Sprites.menuBoard.setLocation(170, 195);
		displayLeaderBoard();
	}
	
//	public void displayLeaderBoard() {
//		List<LeaderBoardScore> scores = fetchLeaderBoard();
//		final int LEADERBOARD_START_X = 200;
//	    final int LEADERBOARD_START_Y = 300;
//	    final int SCORE_GAP_Y = 30;  // Vertical gap between scores
//
//	    //clearLeaderBoardDisplay();  // Clears the previous leaderboard display
//
//	    int yPosition = LEADERBOARD_START_Y;
//	    for (LeaderBoardScore score : scores) {
//	    	String scoreText = score.getUsername() + ": " + score.getScoreValue();
//	    	GLabel scoreLabel = new GLabel(scoreText);
//	    	scoreLabel.setFont("Arial-Bold-18");
//	    	scoreLabel.setColor(Color.BLUE);
//	    	add(scoreLabel, LEADERBOARD_START_X, yPosition);
//	    	yPosition += SCORE_GAP_Y; // Move down for the next score
//	    	}
//	}

	public void displayLeaderBoard() {
		List<LeaderBoardScore> scores = fetchLeaderBoard();
		final int LEADERBOARD_START_X = 195;
		final int LEADERBOARD_START_Y = 215;
		final int SCORE_GAP_Y = 20;

		int yPosition1 = LEADERBOARD_START_Y;
		int yPosition2 = LEADERBOARD_START_Y;
		int count = 0;

		for (LeaderBoardScore score : scores) {
			String scoreText = score.getUsername() + ": " + score.getScoreValue();
			GLabel scoreLabel = new GLabel(" " + scoreText);
			scoreLabel.setFont("Arial-Bold-11");
			scoreLabel.setColor(Color.BLACK);

			if (count < 5) {
				add(scoreLabel, LEADERBOARD_START_X, yPosition1);
				yPosition1 += SCORE_GAP_Y;
			} else {
				add(scoreLabel, LEADERBOARD_START_X + 111, yPosition2);
				yPosition2 += SCORE_GAP_Y;
			}

			count++;
		}
	}

//	private void drawScores(List<Integer> scores) {
//		// Starting coordinates for sets of scores
//		double x1 = 215;
//		double y1 = 217;
//		double x2 = 330;
//		double y2 = 217;
//
//		int count = 0;
//		for (Integer score : scores) {
//			// Draw scores in first location
//			if (count < 5) {
//				GLabel mainLabel = new GLabel("=> " + score);
//				mainLabel.setFont("Arial-Bold-15");
//				mainLabel.setColor(Color.BLACK);
//				add(mainLabel, x1, y1);
//				y1 += 20;
//			}
//			// Draw scores in second location
//			else {
//				GLabel mainLabel = new GLabel("=> " + score);
//				mainLabel.setFont("Arial-Bold-15");
//				mainLabel.setColor(Color.BLACK);
//				add(mainLabel, x2, y2);
//				y2 += 20;
//			}
//			count++;
//		}
//	}
}

