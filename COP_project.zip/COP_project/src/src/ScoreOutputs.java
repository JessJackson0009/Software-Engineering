package src; /** For new high score file, to update high score file, to update high scores list. **/

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScoreOutputs {

    final static String ENCODING = "UTF-8";
    private String highScoreFileName;

    /** Create a new high score file **/
    public ScoreOutputs() {
        this.highScoreFileName = "topHighScore.txt";
        if (!fileExists(highScoreFileName)) {
            writeToFile(highScoreFileName, "0");
        }
    }

    /** Update high score with a new score **/
    public void updateHighScore(String newScore) {
        writeToFile(highScoreFileName, newScore);
    }

    /** Retrieve current high score from the file **/
    public String getHighScore() {
        return readFirstLine(highScoreFileName);
    }

    /** Write a string to a file **/
    private void writeToFile(String fileTxt, String string) {
        try (PrintWriter writer = new PrintWriter(fileTxt, ENCODING)) {
            writer.println(string);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Read first line from a file **/
    private String readFirstLine(String fileTxt) {
        String line = "0"; // Default to 0 if file or line is not found
        try (BufferedReader reader = new BufferedReader(new FileReader(fileTxt))) {
            line = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return line;
    }

    /** Check if file exists **/
    private boolean fileExists(String fileTxt) {
        File file = new File(fileTxt);
        return file.exists();
    }

    /** Appends high score to a file if it's not 0 */
    public void appendHighScore(String newScore) {
        if (!newScore.equals("0")) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("totalHighScores.txt", true))) {
                writer.write(newScore);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /** Reads totalHighScores file and returns the top ten scores **/
    public List<Integer> getTopScores() {
        List<Integer> topScores = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("totalHighScores.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int score = Integer.parseInt(line);
                topScores.add(score);
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        Collections.sort(topScores, Collections.reverseOrder());
        // Keep only top ten scores
        if (topScores.size() > 10) {
            topScores = topScores.subList(0, 10);
        }

        return topScores;
    }

}

