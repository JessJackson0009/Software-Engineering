package src; /**  register new user to enter Applet. **/

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;


public class SignupForm extends JDialog {
	private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean succeeded;
    private String newTitle ="";

    public SignupForm(Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        this.succeeded = false;
        this.newTitle= title;
        //this.userDatabase = new HashMap<>();
        //loadUserDatabase();

        // This doesn't work for my desktop for some reason, it looked pretty once and I dunno how to do it again
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.CYAN);

        JPanel loginPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;

        JLabel usernameLabel = new JLabel("Username: ");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(10, 10, 0, 10);
        loginPanel.add(usernameLabel, constraints);

        usernameField = new JTextField(20);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        loginPanel.add(usernameField, constraints);

        JLabel passwordLabel = new JLabel("Password: ");
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        loginPanel.add(passwordLabel, constraints);

        passwordField = new JPasswordField(20);
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        loginPanel.add(passwordField, constraints);
        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	backToLogin();
            }
        });

        JButton loginButton = new JButton("Login!");
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        loginPanel.add(loginButton, constraints);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	backToLogin();
            }
        });

        JButton registerButton = new JButton("Register!");
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        loginPanel.add(registerButton, constraints);
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	signUp(e);
            }
        });

        contentPane.add(loginPanel, BorderLayout.CENTER);

        setContentPane(contentPane);
        pack();
        setLocationRelativeTo(parent);
        LoginDialogManager.getInstance().hideLoginDialog();
        
    }
	
    public String getNewTitle(){
    	return newTitle;
    }
    
	   private void signUp(ActionEvent e) {
        try {
            URL url = new URL("https://wtmapp.us/classapi/signup");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String jsonInputString = String.format("{\"username\": \"%s\", \"password\": \"%s\"}", username, password);
            
            
            System.out.println("trying to signup as: " +jsonInputString);
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                StringBuilder response = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                System.out.println("signup response" +response.toString());
                // Assuming the API response contains a "message" key
                if (response.toString().contains("User created successfully")) {
                    JOptionPane.showMessageDialog(this, "Signup Successful!");
                    succeeded = true;
                    backToLogin();
                } else {
                    JOptionPane.showMessageDialog(this, response.toString());
                    clearForm();
                    succeeded = false;
                   
                }
            } else {
                JOptionPane.showMessageDialog(this, "Signup Failed!");
                System.out.println("response code:" +responseCode);
                clearForm();
                succeeded = false;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            clearForm();
            succeeded = false;
        }
    }

	
	private void backToLogin() {
		 LoginDialogManager.getInstance().showLoginDialog();
		 this.dispose();
	}
	
	
	private void clearForm() {
        usernameField.setText("");
        passwordField.setText("");
    }


}
