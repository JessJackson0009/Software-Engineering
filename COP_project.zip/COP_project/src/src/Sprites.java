package src; /** Load sprites from Images file, sets a strict location for them (at first). **/

import acm.graphics.*;

public abstract class Sprites {

	public static GImage background, foreground,
			ospreyOG, ospreyFlapUp, ospreyFlapDown, ospreyGameOver,
			botspreyOG, botspreyFlapUp, botspreyFlapDown, botspreyGameOver,
			swoopLogo, tapInstructions, gameOver, scoreboard, replayButton,
			scoreIcon, pauseIcon, playIcon,
			menuBoard, newUser, logIn, preGame, preGame1, postGame,
			newScoreTag;

	public static GImage[] pipeTop = new  GImage[4], pipeBottom = new GImage[4],
			highScoreNums = new  GImage[10], currentScoreNums = new GImage[10],
			scoreNums = new GImage[10], boardNums = new GImage[20];


	/** Loads/sets location of sprites. **/
	public static void init(){
		Sprites.loadImages();
		Sprites.setLocations();
	}

	/** Load the sprites. **/
	public static void loadImages(){

		// Back/foreground
		Sprites.background = new GImage("Images/backgroundbig.png");
		Sprites.foreground = new GImage("Images/groundbig.png");

		// Pipes
		for(int i = 0; i < 4; i++){
			Sprites.pipeTop[i] = new GImage("Images/toppipe.png");
			Sprites.pipeBottom[i] = new GImage("Images/bottompipe.png");
		}

		// Scoreboard
		for (int i = 0; i < 10; i++) {
			String imageName = "Images/med" + i + ".png";
			Sprites.highScoreNums[i] = new GImage(imageName);
		}

		for (int i = 0; i < 10; i++) {
			String imageName = "Images/big" + i + ".png";
			Sprites.currentScoreNums[i] = new GImage(imageName);
		}

		// Load/scale down Osprey
		Sprites.ospreyFlapUp = new GImage("Images/mascotspriteup.png");
		Sprites.ospreyOG = new GImage("Images/mascotsprite.png");
		Sprites.ospreyFlapDown = new GImage("Images/mascotspritedown.png");
		Sprites.ospreyGameOver = new GImage("Images/mascotspritedead.png");
		ospreyFlapUp.setSize(ospreyFlapUp.getWidth() / 14, ospreyFlapUp.getHeight() / 12);
		ospreyOG.setSize(ospreyOG.getWidth() / 14, ospreyOG.getHeight() / 12);
		ospreyFlapDown.setSize(ospreyFlapDown.getWidth() / 14, ospreyFlapDown.getHeight() / 12);
		ospreyGameOver.setSize(ospreyGameOver.getWidth() / 14, ospreyGameOver.getHeight() / 12);

		// Load/scale down Botsprey
		Sprites.botspreyFlapUp = new GImage("Images/botmascotspriteup.png");
		Sprites.botspreyOG = new GImage("Images/botmascotsprite.png");
		Sprites.botspreyFlapDown = new GImage("Images/botmascotspritedown.png");
		Sprites.botspreyGameOver = new GImage("Images/botmascotspritedead.png");
		botspreyFlapUp.setSize(botspreyFlapUp.getWidth() / 14, botspreyFlapUp.getHeight() / 12);
		botspreyOG.setSize(botspreyOG.getWidth() / 14, botspreyOG.getHeight() / 12);
		botspreyFlapDown.setSize(botspreyFlapDown.getWidth() / 14, botspreyFlapDown.getHeight() / 12);
		botspreyGameOver.setSize(botspreyGameOver.getWidth() / 14, botspreyGameOver.getHeight() / 12);

		// Other images
		Sprites.swoopLogo = new GImage("Images/swoopdlooplogo.png");
		swoopLogo.setSize(swoopLogo.getWidth() / 4, swoopLogo.getHeight() / 4);

		Sprites.tapInstructions = new GImage("Images/instructions.png");
		Sprites.gameOver = new GImage("Images/gameover.png");
		Sprites.replayButton = new GImage("Images/playbutton.png");
		Sprites.scoreboard = new GImage("Images/score.png");
		Sprites.newScoreTag = new GImage("Images/newicon.png");
		Sprites.pauseIcon = new GImage("Images/pause.png");
		Sprites.playIcon = new GImage("Images/playicon.png");
		Sprites.menuBoard = new GImage("Images/newscoremenu.png");
		Sprites.scoreIcon = new GImage("Images/scoreicon.png");
		Sprites.logIn = new GImage("Images/login.png");
		Sprites.newUser = new GImage("Images/newUser.png");
		Sprites.preGame = new GImage("Images/poll1.png");
		Sprites.preGame1 = new GImage("Images/poll1.png");
		Sprites.postGame = new GImage("Images/poll2.png");

	}

	/** Set sprite locations (at first). **/
	private static void setLocations(){

		// Foreground
		Sprites.foreground.setLocation(0, 400);

		// Osprey
		Sprites.ospreyOG.setLocation(-80, 0);
		Sprites.ospreyFlapDown.setLocation(-80, 0);
		Sprites.ospreyFlapUp.setLocation(-80, 0);
		Sprites.ospreyGameOver.setLocation(275, 571);

		// Bot
		Sprites.botspreyOG.setLocation(-80, 0);
		Sprites.botspreyFlapDown.setLocation(-80, 0);
		Sprites.botspreyFlapUp.setLocation(-80, 0);
		Sprites.botspreyGameOver.setLocation(275, 571);

		// Other images
		Sprites.swoopLogo.setLocation(150,  320);
		Sprites.tapInstructions.setLocation(230, 180);
		Sprites.gameOver.setLocation(190, 130);
		Sprites.replayButton.setLocation(230, 330);
		Sprites.scoreboard.setLocation(170, 195);
		Sprites.scoreIcon.setLocation(270, 240);
		Sprites.pauseIcon.setLocation(515, 20);
		Sprites.playIcon.setLocation(515, 20);
		Sprites.menuBoard.setLocation(-200, -200);
		Sprites.logIn.setLocation(-200, -200);
		Sprites.newUser.setLocation(-200, -200);
		Sprites.preGame1.setLocation(230, 470);
		Sprites.preGame.setLocation(270, 205);
		Sprites.postGame.setLocation(270, 205);

	}

}