package src; /** For sounds like the applet music, the coin 'ding!', the flaps and the collision/falling. **/

import javax.sound.sampled.*;
import java.io.*;

public class SoundEffects {
	public static void playSound(String filename, boolean loop) {
		try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(filename).getAbsoluteFile());
			Clip clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			if (loop) {
				clip.loop(Clip.LOOP_CONTINUOUSLY); // Set clip to loop continuously
			}
			clip.start();
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}
}

