var Db = require('./classapplication');
const application = require('./classapplication');

var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
var app = express();
var router = express.Router({ caseSensitive: false });
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
var cookieParser = require('cookie-parser');
app.use(cookieParser());

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

router.get('/', (req, res) => {
    console.log('API Base Route Accessed');
    res.json({ message: 'API is operational' });
});


const secretKey = '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08';

var rateLimit = require('express-rate-limit');
const apiLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10000, // limit each IP to 50 requests per windowMs
  message: "Too many requests, please try again later.",
  headers: true, // Sends headers with rate limiting info
  keyGenerator: function(req) {
    // Use the Cloudflare header first, if not available fall back to default IP
    return req.headers['cf-connecting-ip'] || req.ip;
  }
});



router.use((request, response, next) => {
    console.log('middleware');
    next();
})

router.use('/signup', apiLimiter);


const saltRounds = 10; // Cost factor for hashing

router.post('/signup', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Use the addUser function from classapplication to insert the new user
        await application.addUser(username, hashedPassword);

        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({ message: 'Error creating user' });
    }
});



router.post('/signin', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await application.getUserByUsername(username);

        if (!user) {
            return res.status(400).json({ message: 'Invalid username or password' });
        }

        const match = await bcrypt.compare(password, user.hashedPassword);
        if (match) {
            // Generate a token
            const token = jwt.sign({ userId: user.userId, username: user.username }, secretKey, { expiresIn: '1h' });

            // Set the token in a cookie
            res.cookie('authToken', token, { httpOnly: true, secure: true, sameSite: 'Strict', maxAge: 3600000 }); // Adjust cookie options as needed

            res.json({ message: 'Authentication successful' });
        } else {
            res.status(400).json({ message: 'Invalid username or password' });
        }
    } catch (error) {
        console.error('Sign in error:', error);
        res.status(500).json({ message: 'Error signing in' });
    }
});




const authenticateToken = (req, res, next) => {
    // Extract the token from the cookies
    const token = req.cookies['authToken'];

    if (token == null) return res.sendStatus(401); // If no token, respond with 401 (Unauthorized)

    jwt.verify(token, secretKey, (err, user) => {
        if (err) return res.sendStatus(403); // If token is not valid, respond with 403 (Forbidden)
        
        req.user = user; // Add the user payload to the request object
        next(); // Continue to the next middleware/route handler
    });
};


router.post('/submit-score', authenticateToken, async (req, res) => {
    try {
        const { score } = req.body;
        const username = req.user.username; // Assuming username is in the token

        if (typeof score !== 'number') {
            return res.status(400).json({ message: 'Score must be a valid number' });
        }

        const topScores = await application.getTopScores();
        if (topScores.length < 10 || score > topScores[topScores.length - 1].score) {
            await application.insertOrUpdateScore(username, score);
            return res.json({ message: 'Score submitted successfully' });
        } else {
            return res.status(400).json({ message: 'Score does not qualify for the top 10' });
        }
    } catch (error) {
        console.error('Error submitting score:', error);
        res.status(500).json({ message: 'Error processing your score' });
    }
});

router.get('/leaderboard', async (req, res) => {
    try {
        const topScores = await application.getTopScores();
        res.json(topScores);
    } catch (error) {
        console.error('Error fetching top scores:', error);
        res.status(500).json({ message: 'Error fetching leaderboard' });
    }
});

app.get('/protected', authenticateToken, (req, res) => {
    res.json({ message: "You've accessed a protected route!", user: req.user });
});

app.use('/classapi', router);




var port = process.env.PORT || 8099;
app.listen(port);
console.log('Order API is runnning at ' + port);