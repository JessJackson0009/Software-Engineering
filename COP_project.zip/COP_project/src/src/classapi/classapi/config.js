const config = {
    host: '127.0.0.1',
    user: 'wtmapp5_classapi',
    password: 'GzvSLWxoJZ4%',
    database: 'wtmapp5_userDatabase',
};

module.exports = config;