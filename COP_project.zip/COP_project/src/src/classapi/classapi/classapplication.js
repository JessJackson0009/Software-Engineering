const config = require('./config');
const mysql = require('mysql');

// Create a database connection pool
const pool = mysql.createPool(config);

async function queryDatabase(query, params) {
    return new Promise((resolve, reject) => {
        pool.getConnection((err, connection) => {
            if (err) {
                reject(err);
                return;
            }
            connection.query(query, params, (queryErr, results) => {
                connection.release();
                if (queryErr) {
                    reject(queryErr);
                } else {
                    resolve(results);
                }
            });
        });
    });
}


async function addUser(username, hashedPassword) {
    const query = 'INSERT INTO Users (username, hashedPassword) VALUES (?, ?)';
    return await queryDatabase(query, [username, hashedPassword]);
}

async function getUserByUsername(username) {
    const query = 'SELECT * FROM Users WHERE username = ?';
    try {
        const results = await queryDatabase(query, [username]);
        if (results.length > 0) {
            return results[0]; // Assuming username is unique, there should only be one result
        } else {
            return null; // No user found
        }
    } catch (err) {
        console.error('Error querying the database:', err);
        throw err; // Rethrow the error to handle it in the calling context
    }
}

async function getTopScores() {
    const query = 'SELECT * FROM Leaderboard ORDER BY score DESC LIMIT 10';
    return await queryDatabase(query);
}


async function insertOrUpdateScore(username, score) {
    // Get the current top 10 scores from the leaderboard
    const topScoresQuery = 'SELECT * FROM Leaderboard ORDER BY score DESC LIMIT 10';
    const topScores = await queryDatabase(topScoresQuery);

    // Check if the current score qualifies for the top 10
    if (topScores.length < 10 || score > topScores[topScores.length - 1].score) {
        // Insert new score since there's room or it's higher than the lowest in top 10
        const insertQuery = 'INSERT INTO Leaderboard (username, score) VALUES (?, ?)';
        await queryDatabase(insertQuery, [username, score]);

        // Ensure only top 10 scores are kept if the leaderboard is overfilled
        if (topScores.length >= 10) {
            // Identify the lowest score now possibly exceeding 10 entries
            const removeExtraScoresQuery = 'DELETE FROM Leaderboard WHERE id NOT IN (SELECT id FROM Leaderboard ORDER BY score DESC LIMIT 10)';
            await queryDatabase(removeExtraScoresQuery);
        }
    }
}

module.exports = {
    addUser,
    getUserByUsername, // Export the newly added function
    queryDatabase, // Continue to export this if you need it elsewhere
	getTopScores,
	insertOrUpdateScore
};