package src; /** This is pretty much just a copy of Osprey, but it flies on its own. **/

import acm.graphics.*;
import acm.program.*;
import java.awt.Rectangle;

public class BotSprey extends SwoopGameplay {

    Rectangle birdRect;
    protected int fallingSpeed = 0;
    protected int hoverCounter = 0;
    protected int x;
    protected int y;
    private int animationFrames = 0;
    boolean hoverDirectionUp = true;

    public BotSprey(int startingX, int startingY) {
        this.x = startingX;
        this.y = startingY;
        this.birdRect = new Rectangle(x, y, (int) Sprites.botspreyOG.getWidth(), (int) Sprites.botspreyOG.getHeight());
    }

    public boolean botPipeCollision() {
        for (GImage pipeTop : Sprites.pipeTop) {
            if (birdRect.intersects(pipeTop.getBounds().toRectangle())) {
                fallingSpeed -= 3;
                return true;
            }
        }
        for (GImage pipeBottom : Sprites.pipeBottom) {
            if (birdRect.intersects(pipeBottom.getBounds().toRectangle())) {
                fallingSpeed -= 3;
                return true;
            }
        }
        return false;
    }

    public void botDraw(GraphicsProgram window){
        Sprites.botspreyFlapDown.setLocation(SwoopGameplay.OSPREY_X_COORD -20, getY() + hoverCounter);
        Sprites.botspreyOG.setLocation(SwoopGameplay.OSPREY_X_COORD -20, getY() + hoverCounter);
        Sprites.botspreyFlapUp.setLocation(SwoopGameplay.OSPREY_X_COORD -20, getY() + hoverCounter);

        if(SwoopGameplay.gameplayMode != 2){
            if(animationFrames % 2 == 0)
                animateBotBird(animationFrames /2, window);

            animationFrames = (animationFrames + 1) % 8;

        }

    }

    /** Makes the bird move downwards towards pipes **/
    public void botFly() {
        hoverBotBird();

        // Calculate target altitude (midpoint between top and bottom pipes)
        int targetAltitude = calculateTargetAltitude();

        setY(getY() - fallingSpeed);

        // Adjust the movement of the bot bird towards target altitude
        if (getY() < targetAltitude) {
            // Bird is below the target altitude, move upwards
            setY(getY() + 1);
        } else if (getY() > targetAltitude) {
            // Bird is above target altitude, move downwards
            setY(getY() - 1);
        }
        birdRect.setLocation(SwoopGameplay.OSPREY_X_COORD - 20, getY() + hoverCounter);
    }

    private int calculateTargetAltitude() {
        // Calculate the midpoint between the top and bottom pipes for bot bird to fly towards
        int pipeIndex = findClosestPipeIndex();
        int topPipeY = (int) Sprites.pipeTop[pipeIndex].getY();
        int bottomPipeY = (int) Sprites.pipeBottom[pipeIndex].getY() + (int) Sprites.pipeBottom[pipeIndex].getHeight();
        return (topPipeY + bottomPipeY) / 2;
    }

    private int findClosestPipeIndex() {
        // Find index of the pipe closest to the bot bird's current position
        int closestPipeIndex = 0;
        int closestDistance = Integer.MAX_VALUE;
        int botBirdY = getY();
        for (int i = 0; i < 4; i++) {
            int topPipeY = (int) Sprites.pipeTop[i].getY();
            int bottomPipeY = (int) Sprites.pipeBottom[i].getY() + (int) Sprites.pipeBottom[i].getHeight();
            int distanceToPipe = Math.abs(botBirdY - (topPipeY + bottomPipeY) / 2);
            if (distanceToPipe < closestDistance) {
                closestDistance = distanceToPipe;
                closestPipeIndex = i;
            }
        }
        return closestPipeIndex;
    }

    /** Animates botSprey **/
    protected void animateBotBird(int index, GraphicsProgram window) {
        switch (index) {
            case 0:
                window.add(Sprites.botspreyOG);
                window.remove(Sprites.botspreyFlapUp);
                break;
            case 1:
                window.add(Sprites.botspreyFlapDown);
                window.remove(Sprites.botspreyOG);
                break;
            case 2:
                window.add(Sprites.botspreyOG);
                window.remove(Sprites.botspreyFlapDown);
                break;
            default:
                window.add(Sprites.botspreyFlapUp);
                window.remove(Sprites.botspreyOG);
                break;
        }
    }


    /** Makes botSprey hover up and down **/
    protected void hoverBotBird(){

        if(hoverDirectionUp){
            hoverCounter--;
            if(hoverCounter == -10)
                hoverDirectionUp = false;
        }
        else{
            hoverCounter++;
            if(hoverCounter == 10)
                hoverDirectionUp = true;
        }

    }

    public void setY(int y){ this.y = y; }
    public void setX(int x){ this.x = x; }
    public int getX(){ return this.x; }
    public int getY(){ return this.y; }

}


