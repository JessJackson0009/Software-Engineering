-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 26, 2024 at 08:59 PM
-- Server version: 10.6.17-MariaDB-log
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wtmapp5_userDatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `Leaderboard`
--

CREATE TABLE `Leaderboard` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `Leaderboard`
--

INSERT INTO `Leaderboard` (`id`, `username`, `score`) VALUES
(1, 'testuser', 1),
(2, 'newuser123', 4),
(3, 'newuser123', 4),
(4, 'newuser123', 4),
(5, 'newuser123', 4),
(6, 'newuser123', 6),
(7, 'newuser123', 2);

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `hashedPassword` char(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`userID`, `username`, `hashedPassword`) VALUES
(1, 'testuser', '$2b$10$q7g.tpJXbLAUVIGUuMcD6O7qZV/ml8SPvGElCGwdBkNAThsD1eVIu'),
(2, 'newuser123', '$2b$10$XQ0NqKJmuAcK6jKBg3ktLeMQ1luIe9NjmB44jH.szk/3bO/HBxENC'),
(3, 'newuser12', '$2b$10$zz/4eRBUFTxOgc8cpclxXebmC9B3n5Ng2P5QtostQ5ZWJL/dl38rO'),
(4, 'new32', '$2b$10$sP1n/2JYfc1wu5Bq7erl/urSuedwT7QkbJNpKm5pnjq1QBIHHHYEm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Leaderboard`
--
ALTER TABLE `Leaderboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Leaderboard`
--
ALTER TABLE `Leaderboard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
