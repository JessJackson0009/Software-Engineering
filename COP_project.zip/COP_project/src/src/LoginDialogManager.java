package src;

import javax.swing.*;

public class LoginDialogManager {
    private static LoginDialogManager instance;
    private LoginDialog loginDialog;

    private LoginDialogManager() {
        // Initialize the login dialog here, ensure it's done on the EDT
        SwingUtilities.invokeLater(() -> {
            loginDialog = new LoginDialog(null, "Swoop! Please Login!", true);
        });
    }

    public static synchronized LoginDialogManager getInstance() {
        if (instance == null) {
            instance = new LoginDialogManager();
        }
        return instance;
    }

    public void showLoginDialog() {
        SwingUtilities.invokeLater(() -> {
            loginDialog.setVisible(true);
        });
    }

    public void hideLoginDialog() {
        SwingUtilities.invokeLater(() -> {
            loginDialog.setVisible(false);
        });
    }

}