package src; /** Draws Osprey, gives it collision and makes it fly. **/

import acm.graphics.*;
import acm.program.*;
import java.awt.Rectangle;

public class Osprey extends SwoopGameplay {

	Rectangle birdRect;
	protected int fallingSpeed = 0;
	protected int hoverCounter = 0;
	private int animationFrames = 0;
	protected int x;
	protected int y;

	public Osprey(int startingX, int startingY) {
		this.x = startingX;
		this.y = startingY;
		this.birdRect = new Rectangle(x, y, (int) Sprites.ospreyOG.getWidth(), (int) Sprites.ospreyOG.getHeight());
	}

	public boolean pipeCollision() {
		for (GImage pipeTop : Sprites.pipeTop) {
			if (birdRect.intersects(pipeTop.getBounds().toRectangle())) {
				return true;
			}
		}
		for (GImage pipeBottom : Sprites.pipeBottom) {
			if (birdRect.intersects(pipeBottom.getBounds().toRectangle())) {
				return true;
			}
		}
		return false;
	}

	/** Draw Osprey. **/
	public void draw(GraphicsProgram window){

		Sprites.ospreyFlapDown.setLocation(SwoopGameplay.OSPREY_X_COORD, getY() + hoverCounter);
		Sprites.ospreyOG.setLocation(SwoopGameplay.OSPREY_X_COORD, getY() + hoverCounter);
		Sprites.ospreyFlapUp.setLocation(SwoopGameplay.OSPREY_X_COORD, getY() + hoverCounter);

		if(SwoopGameplay.gameplayMode != 2){
			if(animationFrames % 2 == 0)
				animateBird(animationFrames /2, window);
			animationFrames = (animationFrames + 1) % 8;
		}
	}

	/** Osprey moves down. **/
	public void fly(){
		fallingSpeed -= 1* SwoopGameplay.gameplayMode;
		this.setY( this.getY() - fallingSpeed);

		// new rectangle location for collision
		birdRect.setLocation(SwoopGameplay.OSPREY_X_COORD, getY() + hoverCounter);
 	}

	/** To ensure Osprey doesn't go out of bounds. **/
	public void capHeight(){
		
		if(getY() + hoverCounter > -16)
			fallingSpeed = 10;

	}

	/** Animate Osprey. **/
	protected void animateBird(int index, GraphicsProgram window) {
		switch (index) {
			case 0:
				window.add(Sprites.ospreyOG);
				window.remove(Sprites.ospreyFlapUp);
				break;
			case 1:
				window.add(Sprites.ospreyFlapDown);
				window.remove(Sprites.ospreyOG);
				break;
			case 2:
				window.add(Sprites.ospreyOG);
				window.remove(Sprites.ospreyFlapDown);
				break;
			default:
				window.add(Sprites.ospreyFlapUp);
				window.remove(Sprites.ospreyOG);
				break;
		}
	}

	public void setY(int y){ this.y = y; }
	public void setX(int x){ this.x = x; }
	public int getX(){ return this.x; }
	public int getY(){ return this.y; }

}
